<?php

namespace Counter;


use Module\ModulePreferences;

class CounterPreferences extends ModulePreferences
{

    public static function getDefaultPreferences()
    {
        return [];
    }
}