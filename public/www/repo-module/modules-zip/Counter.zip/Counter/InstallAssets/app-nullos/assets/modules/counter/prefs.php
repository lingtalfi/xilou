<?php

$store = [
    '_month' => '2016-03',
];
