<section class="pad">
    <div class="tac boxy">
        <?php echo __("Need help? Please visit the {link}.", LL, [
            'link' => linkt(__("Counter module documentation", LL), doclink("modules/stats-module.md"), true)
        ]); ?>
    </div>
</section>