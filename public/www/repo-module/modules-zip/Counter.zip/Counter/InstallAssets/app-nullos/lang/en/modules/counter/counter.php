<?php


$defs = [];